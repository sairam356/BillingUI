 $(document).ready(function(){


 getCustomerData();


 getProductData();


 getOrderData();



 $("#createOrder").click(function(event){
event.preventDefault();
var   orderObj  = JSON.parse(sessionStorage.getItem("createOrdeObj"));


 $.ajax({
                  url: "http://localhost:9090/order", 
                 type: "POST",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(orderObj),
                success: function (result) {
                           console.log(result);      
                            var url = "/index.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

  
 });

 $("#calcualteTrasportAmount").click(function(event){
    event.preventDefault();
      var tranPortVal = $('#trasportAmount').val();
      var ToFloatTranportAmount = parseFloat(tranPortVal);
      var orderObj =  JSON.parse(sessionStorage.getItem("createOrdeObj"));
      console.log(orderObj);
      var netAmount = orderObj.netAmount;
      var netPayAmount = (orderObj.netAmount - ToFloatTranportAmount).toFixed(2);
      orderObj.transportAmount = ToFloatTranportAmount;
      orderObj.netAfterRemovingTransportAmount = netPayAmount;
      console.log(orderObj);
      sessionStorage.setItem("createOrdeObj", JSON.stringify(orderObj));
      $("#showAllValues2").show();
      $("#netPayAmount").val(netPayAmount);

   
 })

 $("#calcualteAllAmount").click(function(event){
  event.preventDefault();
  
  var  finalObj ={}
  

 var productAryList = JSON.parse(sessionStorage.getItem("orderProductArry"));
 if(productAryList.length>0){

    finalObj.productDTO = productAryList;
 var   custObj = JSON.parse(sessionStorage.getItem("selectedCustomerId"));
  finalObj.customerId = custObj.customerName;
 var totalAmount =0;

  for(let i =0;i<productAryList.length;i++){

       totalAmount = (totalAmount+productAryList[i].calualteAmount).toFixed(2);
  }
 finalObj.totalGrossAmount = totalAmount;


 var avgPerCentage = parseFloat(custObj.gstPerCentage/2);
 var totalPercentage = parseFloat(custObj.gstPerCentage);

 var totalGstAmount = ((totalAmount*totalPercentage) / 100).toFixed(2);
console.log(avgPerCentage+ "  "+custObj.gstPerCentage+"  "+totalGstAmount);

 finalObj.netAmount = (totalAmount - totalGstAmount).toFixed(2) ;
 finalObj.csgstAmount= (totalGstAmount/2).toFixed(2);
 finalObj.sgstAmount=   (totalGstAmount/2).toFixed(2)  ;
 finalObj.gstPerCentage =custObj.gstPerCentage;
   $("#showButton").show();
   $("#showAllValues").show();
   $("#showAllValues1").show();
 
   sessionStorage.setItem("createOrdeObj", JSON.stringify(finalObj));
   console.log(finalObj);
   $('#totalAmountId').val(finalObj.totalGrossAmount);
   $('#netAmountId').val(finalObj.netAmount);
   $('#csgstAmountId').val(finalObj.csgstAmount);
   $('#sgstAmountId').val( finalObj.sgstAmount);
   $("#totalGSTAmount").val(totalGstAmount);


}

 });

 $("#addCustomer").click(function(event) {
            event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");
  });


 console.log(obj);

             $.ajax({
                  url: "http://localhost:9090/cust", 
                 type: "POST",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(obj),
                success: function (result) {
                           console.log(result);      
                            var url = "/customerlist.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
 });   


 $("#editCustomer").click(function(event) {
            event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");
  });


 console.log(obj);

             $.ajax({
                  url: "http://localhost:9090/cust", 
                 type: "PUT",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(obj),
                success: function (result) {
                           console.log(result);
                            var url = "/customerlist.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
 });  



 $("#addProductToOrder").click(function(event){

    event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");
  });
var custObj ={};
custObj.customerName = obj.customerName;
custObj.gstPerCentage = obj.gstPerCentage;
custObj.modifiedPrice = obj.modifiedPrice;
sessionStorage.setItem("selectedCustomerId", JSON.stringify(custObj));
 var productAryList = JSON.parse(sessionStorage.getItem("orderProductArry"));
    if(productAryList.length>0){
        
        var pOrderObj ={};
        pOrderObj.productId = obj.productName;
        pOrderObj.qnty = obj.qnty;
        pOrderObj.gstPerCentage = obj.gstPerCentage;
         $.ajax({
                  url: "http://localhost:9090/product/"+pOrderObj.productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                    pOrderObj.productName = result.productName;
                    pOrderObj.productCode = result.productCode;
                    pOrderObj.productBasePrice = result.basePrice;
                    pOrderObj.modifiedPrice = obj.modifiedPrice;
                    var calcualtePrice =0;
                    if(obj.modifiedPrice == 0)
                    {
                       
                          var qunatity = parseInt(pOrderObj.qnty);
                          calcualtePrice = (qunatity * pOrderObj.productBasePrice);
                         console.log(calcualtePrice);
                    }else{

                         var qunatity = parseInt(pOrderObj.qnty);
                          calcualtePrice = (qunatity * pOrderObj.modifiedPrice);
                         console.log(calcualtePrice);

                    }

                    pOrderObj.calualteAmount = calcualtePrice;
                    productAryList.push(pOrderObj);

                    console.log(productAryList);

                    sessionStorage.setItem("orderProductArry", JSON.stringify(productAryList));

                    var tableData="";
                     for (let i = 0; i < productAryList.length; i++) {
                    tableData = tableData+'<tr><th scope="row">'+i+'</th>'+'<td>'+productAryList[i].productName+
                                        '</td><td>'+productAryList[i].productCode+'</td><td>'+productAryList[i].productBasePrice+'</td><td>'+ productAryList[i].qnty+'</td><td>'+
                                        productAryList[i].calualteAmount+'</td><td> <button onclick="deleteProdutArryObj('+productAryList[i].productId+')"> Delete</button></td></tr>';
                           
               
                        $("#orderRelatedProductData").html(tableData);

                    }
                 },
                error: function (err) {
                    console.log(err);

               }
           });
          


    } else {

        var pArray =[];
        var pOrderObj ={};
        pOrderObj.productId = obj.productName;
        pOrderObj.qnty = obj.qnty;
        pOrderObj.gstPerCentage = obj.gstPerCentage;


    $.ajax({
                  url: "http://localhost:9090/product/"+pOrderObj.productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                    pOrderObj.productName = result.productName;
                    pOrderObj.productCode = result.productCode;
                    pOrderObj.productBasePrice = result.basePrice;
                     var calcualtePrice =0;
                    if(obj.modifiedPrice == 0)
                    {
                       
                          var qunatity = parseInt(pOrderObj.qnty);
                          calcualtePrice = (qunatity * pOrderObj.productBasePrice);
                         console.log(calcualtePrice);
                    }else{

                         var qunatity = parseInt(pOrderObj.qnty);
                          calcualtePrice = (qunatity * pOrderObj.modifiedPrice);
                         console.log(calcualtePrice);

                    }         
                    pOrderObj.calualteAmount = calcualtePrice;
                    pArray.push(pOrderObj);

                    console.log(pArray);

                    sessionStorage.setItem("orderProductArry", JSON.stringify(pArray));

                    var tableData="";
                    tableData = tableData+'<tr><th scope="row">'+1+'</th>'+'<td>'+pOrderObj.productName+
                                        '</td><td>'+pOrderObj.productCode+'</td><td>'+pOrderObj.productBasePrice+'</td><td>'+ pOrderObj.qnty+'</td><td>'+
                                        pOrderObj.calualteAmount+'</td><td> <button onclick="deleteProdutArryObj('+pOrderObj.productId+')"> Delete</button></td></tr>';
                           
               
                        $("#orderRelatedProductData").html(tableData);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 



    }
    

 });


});


 function deleteProdutArryObj(productId){
    console.log("######### delete productID "+productId);

     var productAryList = JSON.parse(sessionStorage.getItem("orderProductArry"));
       var index ;
    if(productAryList.length>0){
      for(let i =0;i<productAryList.length;i++){

          if(productAryList[i].productId == productId){
                     index = i;
                    break;
                }
      }
     productAryList.splice(index, 1);
    }
     sessionStorage.setItem("orderProductArry", JSON.stringify(productAryList));

     var tableData="";
                     for (let i = 0; i < productAryList.length; i++) {
                    tableData = tableData+'<tr><th scope="row">'+i+'</th>'+'<td>'+productAryList[i].productName+
                                        '</td><td>'+productAryList[i].productCode+'</td><td>'+productAryList[i].productBasePrice+'</td><td>'+ productAryList[i].qnty+'</td><td>'+
                                        productAryList[i].calualteAmount+'</td><td> <button onclick="deleteProdutArryObj('+productAryList[i].productId+')"> Delete</button></td></tr>';
                           
               
                        $("#orderRelatedProductData").html(tableData);

                    }
        if(productAryList.length ==0){
            $("#orderRelatedProductData").html(tableData); 
        }

 }

function getCustomerDataById(){
    
    var urlParams = new URLSearchParams(window.location.search);
    var  customerId =urlParams.get('customerId')
     console.log(customerId);

    $.ajax({
                  url: "http://localhost:9090/cust/"+customerId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                 $("#customerId").val(result.customerId);
                 $("#customerName").val(result.customerName);

                 $("#email").val(result.email);
                 $("#mobileNumber").val(result.mobileNumber);
                 $("#GSTNumber").val(result.gstnumber);
                 $("#address").val(result.address);
                 $("#companyName").val(result.companyName);
                 $("#department").val(result.department);
                 $("#city").val(result.city);
                 $("#pincode").val(result.pincode);
                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

}



function  getCustomerData(){
    $.ajax({
                  url: "http://localhost:9090/cust", 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                    localStorage.setItem("customerList", JSON.stringify(result));
                   var tableData ="";
                     for (let i = 0; i < result.length; i++) {
                         console.log(result[i].pincode);
                          tableData = tableData+'<tr><th scope="row">'+result[i].customerId+'</th>'+'<td>'+result[i].customerName+
                            '</td><td>'+result[i].email+'</td><td>'+result[i].mobileNumber+'</td><td>'+
                            result[i].gstnumber+'</td><td>'+result[i].companyName+'</td><td>'+result[i].department+'</td><td>'+
                            result[i].address+'</td><td>'+result[i].city+'</td><td>'+result[i].pincode+'</td><td> <a href = editCustomer.html?customerId='+result[i].customerId+'> Edit</a></td></tr>';                     
                    }     

                   $('#customerData').html(tableData);


                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
}


function getProductData(){
    $.ajax({
                  url: "http://localhost:9090/product", 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                           localStorage.setItem("productList", JSON.stringify(result));
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
}

function getOrderData(){
    $.ajax({
                  url: "http://localhost:9090/order", 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                           localStorage.setItem("orderList", JSON.stringify(result));
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
}

function loadOrderSetup(){
    var orderProductArry =[];
    var customerOptionData ="";
    var productOptionData ="";
    var finalObj={};
     sessionStorage.setItem("createOrdeObj", JSON.stringify(finalObj));
    

   var custObj ={};
   sessionStorage.setItem("selectedCustomerId", JSON.stringify(custObj));
    sessionStorage.setItem("orderProductArry", JSON.stringify(orderProductArry));
     var productAryList = JSON.parse(localStorage.getItem("productList"));
      
    var customerListData = JSON.parse(localStorage.getItem("customerList"));

       for (let i = 0; i < customerListData.length; i++) {
                 
                 customerOptionData = customerOptionData+ '<option value="'+customerListData[i].customerId+'">'+customerListData[i].customerName+'</option>';

       }
 
       for (let i = 0; i < productAryList.length; i++) {
                 
                 productOptionData = productOptionData+ '<option value="'+productAryList[i].productId+'">'+productAryList[i].productName+'</option>';

       }
       $("#showButton").hide();
       $("#showAllValues").hide();
       $("#showAllValues1").hide();
        $("#showAllValues2").hide();
       $('#customerNameList').append(customerOptionData);

       $('#productNameList').append(productOptionData);


}